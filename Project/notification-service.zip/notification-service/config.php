

<?php

if (!defined('EMAIL_HOST')) {
    define('EMAIL_HOST', 'smtp.gmail.com');
}

if (!defined('EMAIL_PORT')) {
    define('EMAIL_PORT', 587);
}

if (!defined('EMAIL_USER')) {
    define('EMAIL_USER', 'projectmahiru@gmail.com');
}

if (!defined('EMAIL_PASS')) {
    define('EMAIL_PASS', 'dmuy ovgx hbsj evik');
}

if (!defined('EMAIL_FROM')) {
    define('EMAIL_FROM', 'Salon Elly');
}
