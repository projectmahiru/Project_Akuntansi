<?php
require 'email.php';

// ✅ IZINKAN CORS
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Content-Type: application/json");

// ✅ JAWAB OPTIONS TANPA RESPONSE JSON
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => false, 'msg' => 'Invalid method']);
    exit;
}

// ✅ Terima dengan JSON (dari Ocelot nanti)
$data = json_decode(file_get_contents("php://input"), true);

$invoice = $data['invoice'] ?? '';
$total   = $data['total'] ?? 0;
$email   = $data['email'] ?? '';

// ✅ FORMAT STRUK
$pesan = "
TERIMA KASIH TELAH BERBELANJA DI SALON KAMI

Invoice : $invoice
Total   : Rp " . number_format($total, 0, ',', '.') . "

Struk ini merupakan bukti pembayaran sah.
";

// ✅ KIRIM EMAIL
$email_status = sendEmail(
    $email,
    "Struk Pembayaran Salon",
    nl2br($pesan)
);

// ✅ RESPONSE KE API GATEWAY
echo json_encode([
    'status' => true,
    'email'  => $email_status
]);
