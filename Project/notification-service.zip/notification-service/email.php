<?php

require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';
require 'phpmailer/src/Exception.php';

require 'config.php';

use PHPMailer\PHPMailer\PHPMailer;

function sendEmail($to, $subject, $body)
{
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = EMAIL_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = EMAIL_USER;
        $mail->Password   = EMAIL_PASS;
        $mail->SMTPSecure = 'tls';
        $mail->Port       = EMAIL_PORT;

        $mail->setFrom(EMAIL_USER, EMAIL_FROM);
        $mail->addAddress($to);

        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $body;

        return $mail->send();
} catch (Exception $e) {
    echo json_encode([
        "status" => false,
        "error" => $mail->ErrorInfo
    ]);
    exit;
}

}
