<?php

$url = "http://localhost/notification-service/index.php";

$data = [
    'invoice' => 'INV-TEST-001',
    'total'   => '85000',
    'email'   => 'gmailkamu@gmail.com',
    'wa'      => '628123456789'
];

$options = [
    'http' => [
        'method'  => 'POST',
        'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
        'content' => http_build_query($data)
    ]
];

$context  = stream_context_create($options);
$result = file_get_contents($url, false, $context);

echo $result;
