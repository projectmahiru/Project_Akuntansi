<?php
require 'config.php';

function sendWhatsapp($target, $message)
{
    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => WA_URL,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array(
            'target' => $target,
            'message' => $message
        ),
        CURLOPT_HTTPHEADER => array(
            'Authorization: ' . WA_API_KEY
        ),
    ));

    $response = curl_exec($curl);
    curl_close($curl);

    return $response;
}
